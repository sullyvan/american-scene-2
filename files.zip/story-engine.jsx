import React, { useState, useEffect, useCallback } from "react";

/* ---------------- Data banks (mirrors story_engine_reference.xlsx) ---------------- */

const INTENTIONS = {
  "Survival": [
    "Escape a collapsing structure or system before it's too late",
    "Outlast a hostile environment long enough to be found",
    "Protect a dependent from an immediate threat",
    "Secure the next meal or shelter for the people relying on them",
  ],
  "Connection / Love": [
    "Reunite with someone they've lost contact with",
    "Win back trust after a specific betrayal",
    "Be truly seen and understood by one particular person",
    "Keep a family from fracturing over an old wound",
  ],
  "Justice / Revenge": [
    "Expose a cover-up before the people responsible walk away clean",
    "Make one specific person answer for a specific wrong",
    "Clear a name that was wrongly blamed",
    "Even an old score before the chance closes forever",
  ],
  "Power / Ambition": [
    "Seize control of an institution from someone unfit to run it",
    "Be recognized as the best at the one thing that matters to them",
    "Outmaneuver a rival for a specific position",
    "Build something that will outlast them",
  ],
  "Freedom / Escape": [
    "Break free of a person or system that controls them",
    "Leave a place that defines them before it's too late",
    "Shed an identity that was assigned to them, not chosen",
    "Get out before a specific deadline closes",
  ],
  "Truth / Knowledge": [
    "Prove something true that everyone insists is false",
    "Find out what actually happened, whatever it costs",
    "Understand why someone they loved did what they did",
    "Expose the lie holding a group together",
  ],
  "Redemption": [
    "Undo the damage of one specific past act",
    "Earn back a relationship they themselves destroyed",
    "Finish what they abandoned once before",
    "Prove they've changed to the one person who refuses to believe it",
  ],
  "Belonging / Legacy": [
    "Be let back into a group that exiled them",
    "Pass something on before it's too late to pass it on",
    "Find the place they actually belong, not the one they were born into",
    "Be remembered for the right thing, not the wrong one",
  ],
};

const OBSTACLES = {
  "External — Institutional": [
    "A bureaucracy with no real interest in their case",
    "A law that makes the goal itself illegal",
    "An organization actively covering for the person responsible",
    "A system with no appeals process",
  ],
  "External — Physical / Environmental": [
    "A deadline that cannot be extended",
    "A distance that can't be closed in time",
    "A disaster actively destroying the thing they're trying to save",
    "A body that is failing faster than the goal can be reached",
  ],
  "External — Adversarial": [
    "A rival pursuing the same goal with better resources",
    "A person actively working to stop them",
    "Someone with power over them who benefits from their failure",
    "An enemy who used to be an ally",
  ],
  "Relational": [
    "A person they love who is also the obstacle",
    "A loyalty that directly conflicts with the goal",
    "A secret that, if revealed, destroys the relationship they need to succeed",
    "A debt owed to the very person blocking them",
  ],
  "Internal — Flaw": [
    "A temper or pride that sabotages their own plans",
    "A fear that makes them freeze at the critical moment",
    "A dependency that keeps undoing their progress",
    "A need for control that alienates the people who could help",
  ],
  "Internal — Belief": [
    "A conviction that they don't deserve the goal",
    "A worldview that makes the real solution invisible to them",
    "Guilt over a past act they think disqualifies them",
    "A refusal to accept help, even when it's offered",
  ],
  "Internal — Identity": [
    "An old version of themselves they haven't let go of",
    "A role others expect that conflicts with what they actually want",
    "A reputation they have to live up to, or down",
    "A fear of becoming someone they hate",
  ],
  "Circumstantial — Resource": [
    "Not enough money, time, or leverage to do it the sanctioned way",
    "A skill they don't have and can't acquire in time",
    "Isolation — no one left who can help",
    "Information withheld that they need in order to proceed",
  ],
};

const RUBRIC = [
  { key: "urgency", label: "Urgency", q: "Does it have to be resolved now?" },
  { key: "stakes", label: "Stakes", q: "What's lost if the obstacle wins?" },
  { key: "formidability", label: "Formidability", q: "Is the obstacle a real threat?" },
  { key: "specificity", label: "Specificity", q: "Is the want concrete, not vague?" },
  { key: "escalation", label: "Escalation", q: "Does it get harder as it goes?" },
];

const BOOKER_PLOTS = [
  { name: "Overcoming the Monster", desc: "protagonist vs. an existential external threat" },
  { name: "Rags to Riches", desc: "rise from lack to abundance" },
  { name: "The Quest", desc: "journey toward a goal, obstacles escalate along the way" },
  { name: "Voyage and Return", desc: "pulled into a strange world, must return changed" },
  { name: "Comedy", desc: "confusion or mistaken identity obstructs connection, resolved by revelation" },
  { name: "Tragedy", desc: "a flaw within the protagonist becomes the true obstacle" },
  { name: "Rebirth", desc: "nearly overcome by darkness (internal or external) before a redemptive turn" },
];

const POLTI_SITUATIONS = [
  { name: "Supplication", desc: "a weaker party pleads with a more powerful one for something essential" },
  { name: "Deliverance", desc: "rescue of a victim by a rescuer, from a threatening party" },
  { name: "Crime Pursued by Vengeance", desc: "a wrongdoer is hunted by an avenger" },
  { name: "Vengeance Taken for Kindred Upon Kindred", desc: "vengeance for a relative, exacted upon another relative" },
  { name: "Pursuit", desc: "fleeing from punishment or a threat" },
  { name: "Disaster", desc: "facing ruin or defeat at the hands of fate or a powerful force" },
  { name: "Falling Prey to Cruelty/Misfortune", desc: "an innocent party suffers at the hands of misfortune or a merciless power" },
  { name: "Revolt", desc: "one or many rise up against a tyrannical authority" },
  { name: "Daring Enterprise", desc: "a bold, risky undertaking against long odds" },
  { name: "Abduction", desc: "someone is taken against their will, or against the will of someone who loves them" },
  { name: "The Enigma", desc: "a problem, riddle, or mystery must be solved" },
  { name: "Obtaining", desc: "pursuit of a coveted object or goal against rivals" },
  { name: "Enmity of Kinsmen", desc: "hatred between family members" },
  { name: "Rivalry of Kinsmen", desc: "competition between family members for the same goal" },
  { name: "Murderous Adultery", desc: "a love triangle escalates to murder" },
  { name: "Madness", desc: "a character's actions are driven by mental breakdown" },
  { name: "Fatal Imprudence", desc: "a moment of carelessness leads to irreversible consequences" },
  { name: "Involuntary Crimes of Love", desc: "a transgression committed unknowingly in the name of love" },
  { name: "Slaying of a Kinsman Unrecognized", desc: "a relative is harmed because they weren't recognized in time" },
  { name: "Self-Sacrifice for an Ideal", desc: "a character gives up everything for a belief or cause" },
  { name: "Self-Sacrifice for Kindred", desc: "a character gives up everything for family" },
  { name: "All Sacrificed for Passion", desc: "reason and duty are abandoned in pursuit of desire" },
  { name: "Necessity of Sacrificing Loved Ones", desc: "a character must choose to sacrifice someone they love for a greater need" },
  { name: "Rivalry of Superior and Inferior", desc: "conflict between parties of unequal power or status" },
  { name: "Adultery", desc: "betrayal of a romantic bond" },
  { name: "Crimes of Love", desc: "a serious offense committed in the name of love" },
  { name: "Discovery of the Dishonor of a Loved One", desc: "a character learns someone they love has done something shameful" },
  { name: "Obstacles to Love", desc: "external or circumstantial forces block a romantic bond" },
  { name: "An Enemy Loved", desc: "a character falls for someone on the opposing side" },
  { name: "Ambition", desc: "a drive for power or status becomes the central conflict" },
  { name: "Conflict with a God", desc: "a character struggles against fate, destiny, or a force beyond their control" },
  { name: "Mistaken Jealousy", desc: "jealousy arises from a false belief" },
  { name: "Erroneous Judgment", desc: "a flawed decision or misjudgment drives the plot" },
  { name: "Remorse", desc: "guilt over a past act becomes the central struggle" },
  { name: "Recovery of a Lost One", desc: "a character searches for someone believed gone" },
  { name: "Loss of Loved Ones", desc: "a character must cope with the death or loss of someone close" },
];

const VONNEGUT_SHAPES = [
  { name: "Man in a Hole", desc: "falls into trouble, works to get out, ends better off than at the start" },
  { name: "Boy Meets Girl", desc: "good fortune, sudden setback, recovery to a happy end" },
  { name: "Cinderella", desc: "steady rise, sudden fall, steady rise to a high ending" },
  { name: "From Bad to Worse", desc: "fortune declines steadily with no real recovery" },
  { name: "Which Way Is Up", desc: "ambiguous events -- can't tell if something is good or bad until much later" },
  { name: "Creation Story", desc: "a steady rise from nothing" },
  { name: "Icarus", desc: "steady rise followed by a steep fall" },
];

const FRAMEWORKS = {
  sorkin: { label: "Sorkin", tagline: "Intention + Obstacle, the drive shaft" },
  booker: { label: "Booker", tagline: "Start from one of 7 plot shapes" },
  polti: { label: "Polti", tagline: "Start from one of 36 dramatic situations" },
  vonnegut: { label: "Vonnegut", tagline: "Start from an emotional arc shape" },
};

const SYSTEM_PROMPT = `You are the analysis engine inside "The Story Engine," a tool built on Aaron Sorkin's Intention/Obstacle method plus Booker's 7 Basic Plots, Polti's 36 Dramatic Situations, and Vonnegut's story shapes.

Sorkin's method: a story's "drive shaft" is Intention (somebody wants something specific) + Obstacle (something formidable stands in their way). Everything else hangs off that.

Score every premise on the Pressing Test, 1-5 each:
- urgency: does it have to be resolved now?
- stakes: what's genuinely lost if the obstacle wins?
- formidability: is the obstacle a real threat of failure?
- specificity: is the want concrete and nameable, not abstract?
- escalation: does the obstacle get harder as the story unfolds?

Always respond with ONLY valid JSON, no markdown fences, no preamble, matching exactly the schema you're given in the user message. Be specific and concrete in all text fields — no vague filler. Keep total output compact.`;

async function callClaude(userPrompt) {
  const response = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      model: "claude-sonnet-4-6",
      max_tokens: 1000,
      system: SYSTEM_PROMPT,
      messages: [{ role: "user", content: userPrompt }],
    }),
  });
  if (!response.ok) throw new Error("API request failed: " + response.status);
  const data = await response.json();
  const text = (data.content || [])
    .filter((b) => b.type === "text")
    .map((b) => b.text)
    .join("\n");
  const cleaned = text.replace(/```json|```/g, "").trim();
  return JSON.parse(cleaned);
}

function pick(bank) {
  const cats = Object.keys(bank);
  const cat = cats[Math.floor(Math.random() * cats.length)];
  const items = bank[cat];
  return items[Math.floor(Math.random() * items.length)];
}

function scoreTotal(scores) {
  if (!scores) return 0;
  return RUBRIC.reduce((sum, r) => sum + (Number(scores[r.key]) || 0), 0);
}

function bandFor(total) {
  if (total >= 21) return { label: "Load-bearing", color: "#4ADE80" };
  if (total >= 15) return { label: "Solid", color: "#F5C144" };
  if (total >= 9) return { label: "Underpowered", color: "#F0913C" };
  return { label: "Not yet a story", color: "#E85D3F" };
}

/* ---------------- Small UI components ---------------- */

function Gauge({ label, value }) {
  const pct = Math.max(0, Math.min(5, value || 0)) / 5;
  const angle = -90 + pct * 180;
  return (
    <div className="gauge">
      <svg viewBox="0 0 100 58" width="100%" height="auto">
        <path d="M 8 54 A 42 42 0 0 1 92 54" fill="none" stroke="#2A3B54" strokeWidth="7" strokeLinecap="round" />
        <path
          d="M 8 54 A 42 42 0 0 1 92 54"
          fill="none"
          stroke="#C98A2E"
          strokeWidth="7"
          strokeLinecap="round"
          strokeDasharray={`${pct * 132} 132`}
        />
        <g transform={`rotate(${angle} 50 54)`}>
          <line x1="50" y1="54" x2="50" y2="18" stroke="#E8ECF1" strokeWidth="2" />
        </g>
        <circle cx="50" cy="54" r="4" fill="#E8ECF1" />
      </svg>
      <div className="gauge-label">{label}</div>
      <div className="gauge-value">{value || "—"}/5</div>
    </div>
  );
}

function DriveShaft({ spinning }) {
  return (
    <div className="driveshaft">
      <div className="ds-node ds-left">
        <div className="ds-ring">
          <div className={"ds-gear" + (spinning ? " spin" : "")}>⚙</div>
        </div>
        <div className="ds-tag">INTENTION</div>
      </div>
      <div className="ds-shaft">
        <div className={"ds-shaft-line" + (spinning ? " active" : "")} />
      </div>
      <div className="ds-node ds-right">
        <div className="ds-ring">
          <div className={"ds-gear" + (spinning ? " spin" : "")}>⚙</div>
        </div>
        <div className="ds-tag">OBSTACLE</div>
      </div>
    </div>
  );
}

function ScoreBand({ total }) {
  const band = bandFor(total);
  return (
    <div className="score-band" style={{ borderColor: band.color }}>
      <span className="score-band-total" style={{ color: band.color }}>{total}/25</span>
      <span className="score-band-label">{band.label}</span>
    </div>
  );
}

function pickFrom(list) {
  return list[Math.floor(Math.random() * list.length)];
}

/* ---------------- Main app ---------------- */

export default function StoryEngine() {
  const [tab, setTab] = useState("generate");
  const [framework, setFramework] = useState("sorkin");
  const [seedIntention, setSeedIntention] = useState("");
  const [seedObstacle, setSeedObstacle] = useState("");
  const [lensSeed, setLensSeed] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [result, setResult] = useState(null);
  const [feedbackInput, setFeedbackInput] = useState("");
  const [feedbackResult, setFeedbackResult] = useState(null);
  const [clashA, setClashA] = useState("");
  const [clashB, setClashB] = useState("");
  const [clashResult, setClashResult] = useState(null);
  const [history, setHistory] = useState([]);
  const [historyLoaded, setHistoryLoaded] = useState(false);

  useEffect(() => {
    (async () => {
      try {
        const res = await window.storage.get("story-engine-history");
        if (res && res.value) setHistory(JSON.parse(res.value));
      } catch (e) {
        /* no history yet */
      } finally {
        setHistoryLoaded(true);
      }
    })();
  }, []);

  const saveHistory = useCallback(async (entry) => {
    setHistory((prev) => {
      const next = [entry, ...prev].slice(0, 30);
      window.storage.set("story-engine-history", JSON.stringify(next), false).catch(() => {});
      return next;
    });
  }, []);

  const lensList = framework === "booker" ? BOOKER_PLOTS : framework === "polti" ? POLTI_SITUATIONS : framework === "vonnegut" ? VONNEGUT_SHAPES : null;

  async function handleGenerate(useRandom) {
    setLoading(true);
    setError(null);
    setResult(null);

    const intention = useRandom || !seedIntention.trim() ? pick(INTENTIONS) : seedIntention.trim();
    const obstacle = useRandom || !seedObstacle.trim() ? pick(OBSTACLES) : seedObstacle.trim();
    if (!useRandom) {
      setSeedIntention(intention);
      setSeedObstacle(obstacle);
    }

    let lensClause = "";
    let item = null;
    if (framework !== "sorkin") {
      const chosen = useRandom || !lensSeed ? pickFrom(lensList).name : lensSeed;
      item = lensList.find((x) => x.name === chosen) || lensList[0];
      if (!useRandom) setLensSeed(chosen);
      lensClause =
        framework === "booker"
          ? `\n\nAdditionally, shape the overall story so it exemplifies Booker's plot type "${item.name}" (${item.desc}).`
          : framework === "polti"
          ? `\n\nAdditionally, shape the central conflict so it exemplifies Polti's dramatic situation "${item.name}" (${item.desc}).`
          : `\n\nAdditionally, shape the story's fortune over time so it follows Vonnegut's "${item.name}" arc shape (${item.desc}). Add a short "arcNote" field describing how fortune rises/falls across the story.`;
    }

    const prompt = `Generate one story premise built from this Intention/Obstacle pair, then score it.

Intention seed: "${intention}"
Obstacle seed: "${obstacle}"

Sharpen both into a specific character situation (don't just restate the seeds), invent a one-line world/character to anchor it.${lensClause}

Then score the result on the Pressing Test.

Respond with ONLY this JSON schema:
{
  "title": "short evocative title, 2-5 words",
  "intention": "the sharpened, specific intention as it applies to this premise",
  "obstacle": "the sharpened, specific obstacle as it applies to this premise",
  "logline": "1-2 sentence logline",
  "plotType": "${framework === "booker" ? item.name : "closest Booker plot, e.g. 'The Quest'"}",
  "polti": "${framework === "polti" ? item.name : "closest Polti situation name"}",
  ${framework === "vonnegut" ? `"vonnegutShape": "${item.name}",\n  "arcNote": "1-2 sentences on how fortune rises/falls across this story",` : ""}
  "scores": {"urgency": 1-5, "stakes": 1-5, "formidability": 1-5, "specificity": 1-5, "escalation": 1-5},
  "pressNotes": "1-2 sentences: which dimension is weakest and how to press it harder"
}`;

    try {
      const data = await callClaude(prompt);
      setResult(data);
      saveHistory({ type: "generate", framework, ts: Date.now(), data });
    } catch (e) {
      setError("Generation failed — try again. (" + e.message + ")");
    } finally {
      setLoading(false);
    }
  }

  async function handleFeedback() {
    if (!feedbackInput.trim()) return;
    setLoading(true);
    setError(null);
    setFeedbackResult(null);
    const prompt = `Analyze this story idea using the Pressing Test and the intention/obstacle framework.

Story idea: """${feedbackInput.trim()}"""

Respond with ONLY this JSON schema:
{
  "restatedIntention": "the intention you identify in this idea, stated specifically",
  "restatedObstacle": "the obstacle you identify in this idea, stated specifically",
  "plotType": "closest Booker plot",
  "polti": "closest Polti situation name",
  "scores": {"urgency": 1-5, "stakes": 1-5, "formidability": 1-5, "specificity": 1-5, "escalation": 1-5},
  "diagnosis": "2-3 sentences: the single biggest weakness and why it matters",
  "strongerObstacle": "one concrete, rewritten obstacle that would score higher, with a one-sentence reason"
}`;
    try {
      const data = await callClaude(prompt);
      setFeedbackResult(data);
      saveHistory({ type: "feedback", ts: Date.now(), input: feedbackInput.trim(), data });
    } catch (e) {
      setError("Analysis failed — try again. (" + e.message + ")");
    } finally {
      setLoading(false);
    }
  }

  async function handleClash() {
    if (!clashA.trim() || !clashB.trim()) return;
    setLoading(true);
    setError(null);
    setClashResult(null);
    const prompt = `You're finding the conceptual through-line between two existing projects/ideas by clashing their Intention/Obstacle DNA together into one new hybrid premise.

Source A: """${clashA.trim()}"""
Source B: """${clashB.trim()}"""

First, identify the core Intention or Obstacle embedded in each source (even if it's not an explicit story — could be a visual project, a body of work, a concept). Then fuse them into one new, specific story premise that genuinely inherits something structural from both — not just a surface mashup. Then score the hybrid on the Pressing Test.

Respond with ONLY this JSON schema:
{
  "title": "short evocative title, 2-5 words",
  "fromA": "the specific intention/obstacle DNA taken from Source A, one phrase",
  "fromB": "the specific intention/obstacle DNA taken from Source B, one phrase",
  "intention": "the hybrid premise's intention",
  "obstacle": "the hybrid premise's obstacle",
  "logline": "1-2 sentence logline for the hybrid premise",
  "plotType": "closest Booker plot",
  "polti": "closest Polti situation name",
  "scores": {"urgency": 1-5, "stakes": 1-5, "formidability": 1-5, "specificity": 1-5, "escalation": 1-5},
  "pressNotes": "1-2 sentences: which dimension is weakest and how to press it harder"
}`;
    try {
      const data = await callClaude(prompt);
      setClashResult(data);
      saveHistory({ type: "clash", ts: Date.now(), inputA: clashA.trim(), inputB: clashB.trim(), data });
    } catch (e) {
      setError("Clash failed — try again. (" + e.message + ")");
    } finally {
      setLoading(false);
    }
  }


  return (
    <div className="app">
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Oswald:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500;700&family=Source+Serif+4:ital,wght@0,400;0,600;1,400&display=swap');

        * { box-sizing: border-box; }
        .app {
          --navy: #0B1220;
          --panel: #101A2B;
          --panel-2: #16233A;
          --line: #24344E;
          --amber: #C98A2E;
          --amber-bright: #E8A63B;
          --cyan: #5EEAD4;
          --ink: #E8ECF1;
          --muted: #7C8DA6;
          background: var(--navy);
          background-image:
            linear-gradient(rgba(94,234,212,0.035) 1px, transparent 1px),
            linear-gradient(90deg, rgba(94,234,212,0.035) 1px, transparent 1px);
          background-size: 28px 28px;
          color: var(--ink);
          min-height: 100vh;
          font-family: 'Source Serif 4', serif;
          padding: 20px 14px 60px;
        }
        .header {
          max-width: 760px;
          margin: 0 auto 22px;
          text-align: center;
        }
        .eyebrow {
          font-family: 'JetBrains Mono', monospace;
          font-size: 11px;
          letter-spacing: 0.18em;
          color: var(--amber);
          text-transform: uppercase;
        }
        .h1 {
          font-family: 'Oswald', sans-serif;
          font-weight: 700;
          font-size: 34px;
          letter-spacing: 0.02em;
          text-transform: uppercase;
          margin: 4px 0 6px;
          background: linear-gradient(180deg, #F3E7CE, var(--amber-bright));
          -webkit-background-clip: text;
          background-clip: text;
          color: transparent;
        }
        .sub {
          color: var(--muted);
          font-size: 14px;
          font-style: italic;
        }

        .tabs {
          max-width: 760px;
          margin: 22px auto 18px;
          display: flex;
          border: 1px solid var(--line);
          border-radius: 3px;
          overflow: hidden;
        }
        .tab-btn {
          flex: 1;
          background: var(--panel);
          border: none;
          color: var(--muted);
          font-family: 'JetBrains Mono', monospace;
          font-size: 11.5px;
          letter-spacing: 0.08em;
          text-transform: uppercase;
          padding: 11px 6px;
          cursor: pointer;
          border-right: 1px solid var(--line);
          transition: background 0.15s, color 0.15s;
        }
        .tab-btn:last-child { border-right: none; }
        .tab-btn.active { background: var(--amber); color: #1A1206; font-weight: 700; }
        .tab-btn:not(.active):hover { background: var(--panel-2); color: var(--ink); }

        .panel {
          max-width: 760px;
          margin: 0 auto;
          background: var(--panel);
          border: 1px solid var(--line);
          border-radius: 4px;
          padding: 22px;
        }

        .driveshaft {
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 0;
          margin: 6px 0 22px;
        }
        .ds-node { display: flex; flex-direction: column; align-items: center; width: 96px; }
        .ds-ring {
          width: 64px; height: 64px; border-radius: 50%;
          border: 2px solid var(--amber);
          display: flex; align-items: center; justify-content: center;
          background: radial-gradient(circle, rgba(201,138,46,0.12), transparent 70%);
        }
        .ds-gear { font-size: 26px; color: var(--amber-bright); }
        .ds-gear.spin { animation: spin 1.4s linear infinite; }
        @keyframes spin { from { transform: rotate(0deg);} to { transform: rotate(360deg);} }
        .ds-tag {
          font-family: 'JetBrains Mono', monospace;
          font-size: 10px; letter-spacing: 0.12em; color: var(--muted);
          margin-top: 8px;
        }
        .ds-shaft { flex: 1; max-width: 220px; height: 2px; position: relative; }
        .ds-shaft-line {
          height: 2px; background: var(--line); width: 100%;
        }
        .ds-shaft-line.active {
          background: linear-gradient(90deg, var(--amber), var(--cyan), var(--amber));
          background-size: 200% 100%;
          animation: flow 1.2s linear infinite;
        }
        @keyframes flow { from { background-position: 0% 0; } to { background-position: 200% 0; } }

        .field-label {
          font-family: 'JetBrains Mono', monospace;
          font-size: 10.5px; letter-spacing: 0.1em; text-transform: uppercase;
          color: var(--muted); margin-bottom: 6px; display: block;
        }
        textarea, input[type=text] {
          width: 100%;
          background: var(--panel-2);
          border: 1px solid var(--line);
          color: var(--ink);
          font-family: 'Source Serif 4', serif;
          font-size: 14.5px;
          padding: 10px 12px;
          border-radius: 3px;
          resize: vertical;
        }
        textarea:focus, input:focus { outline: 2px solid var(--cyan); outline-offset: 1px; }
        .seed-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin-bottom: 16px; }
        @media (max-width: 520px) { .seed-grid { grid-template-columns: 1fr; } }

        .lens-row { display: grid; grid-template-columns: repeat(4, 1fr); gap: 8px; margin: 8px 0 18px; }
        @media (max-width: 560px) { .lens-row { grid-template-columns: repeat(2, 1fr); } }
        .lens-btn {
          display: flex; flex-direction: column; align-items: flex-start; gap: 3px;
          background: var(--panel-2); border: 1px solid var(--line); border-radius: 3px;
          padding: 9px 10px; cursor: pointer; text-align: left;
          transition: border-color 0.15s, background 0.15s;
        }
        .lens-btn:hover { border-color: var(--amber); }
        .lens-btn.active { border-color: var(--amber); background: rgba(201,138,46,0.14); }
        .lens-btn-label { font-family: 'Oswald', sans-serif; font-size: 13px; text-transform: uppercase; letter-spacing: 0.03em; color: var(--ink); }
        .lens-btn-tagline { font-family: 'JetBrains Mono', monospace; font-size: 9.5px; color: var(--muted); line-height: 1.3; }
        .lens-note {
          font-family: 'JetBrains Mono', monospace; font-size: 11px; color: var(--cyan);
          margin: -6px 0 14px; line-height: 1.4;
        }

        select {
          width: 100%;
          background: var(--panel-2);
          border: 1px solid var(--line);
          color: var(--ink);
          font-family: 'Source Serif 4', serif;
          font-size: 14px;
          padding: 9px 10px;
          border-radius: 3px;
        }
        select:focus { outline: 2px solid var(--cyan); outline-offset: 1px; }

        .clash-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 14px; margin-bottom: 16px; }
        @media (max-width: 520px) { .clash-grid { grid-template-columns: 1fr; } }

        .btn-row { display: flex; gap: 10px; flex-wrap: wrap; margin-top: 4px; }
        .btn {
          font-family: 'JetBrains Mono', monospace;
          font-size: 12px; letter-spacing: 0.06em; text-transform: uppercase;
          padding: 11px 18px;
          border-radius: 3px;
          border: 1px solid var(--amber);
          background: transparent;
          color: var(--amber-bright);
          cursor: pointer;
          transition: background 0.15s, color 0.15s;
        }
        .btn:hover:not(:disabled) { background: var(--amber); color: #1A1206; }
        .btn:disabled { opacity: 0.45; cursor: not-allowed; }
        .btn.primary { background: var(--amber); color: #1A1206; }
        .btn.primary:hover:not(:disabled) { background: var(--amber-bright); }

        .error-box {
          margin-top: 14px; padding: 10px 12px;
          border: 1px solid #E85D3F; color: #F0A88E;
          font-family: 'JetBrains Mono', monospace; font-size: 12px;
          border-radius: 3px;
        }

        .result { margin-top: 22px; border-top: 1px solid var(--line); padding-top: 20px; }
        .result-title {
          font-family: 'Oswald', sans-serif; font-weight: 600; font-size: 22px;
          color: #F3E7CE; margin-bottom: 4px;
        }
        .result-tags { display: flex; gap: 8px; flex-wrap: wrap; margin-bottom: 14px; }
        .tag {
          font-family: 'JetBrains Mono', monospace; font-size: 10.5px;
          border: 1px solid var(--line); color: var(--cyan);
          padding: 3px 8px; border-radius: 20px;
        }
        .logline { font-size: 16px; line-height: 1.55; margin-bottom: 18px; color: var(--ink); }
        .io-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 14px; margin-bottom: 20px; }
        @media (max-width: 520px) { .io-grid { grid-template-columns: 1fr; } }
        .io-card { background: var(--panel-2); border: 1px solid var(--line); border-radius: 3px; padding: 12px 14px; }
        .io-card .field-label { color: var(--amber); }
        .io-card p { margin: 0; font-size: 14px; line-height: 1.5; }

        .gauges { display: grid; grid-template-columns: repeat(5, 1fr); gap: 10px; margin-bottom: 16px; }
        @media (max-width: 520px) { .gauges { grid-template-columns: repeat(3, 1fr); } }
        .gauge { text-align: center; }
        .gauge-label { font-family: 'JetBrains Mono', monospace; font-size: 9.5px; letter-spacing: 0.05em; color: var(--muted); margin-top: 2px; text-transform: uppercase; }
        .gauge-value { font-family: 'JetBrains Mono', monospace; font-size: 12px; color: var(--ink); font-weight: 700; }

        .score-band {
          display: inline-flex; align-items: center; gap: 8px;
          border: 1px solid; border-radius: 20px; padding: 5px 14px; margin-bottom: 14px;
          font-family: 'JetBrains Mono', monospace; font-size: 12px;
        }
        .score-band-total { font-weight: 700; }

        .press-notes {
          font-size: 13.5px; color: var(--muted); font-style: italic; line-height: 1.5;
          border-left: 2px solid var(--amber); padding-left: 12px;
        }

        .history-list { margin-top: 8px; }
        .history-item {
          border: 1px solid var(--line); border-radius: 3px; padding: 10px 12px; margin-bottom: 8px;
          font-size: 13px; cursor: pointer; transition: border-color 0.15s;
        }
        .history-item:hover { border-color: var(--amber); }
        .history-item .h-type { font-family: 'JetBrains Mono', monospace; font-size: 9.5px; color: var(--cyan); text-transform: uppercase; letter-spacing: 0.08em; }
        .history-item .h-title { font-family: 'Oswald', sans-serif; font-size: 15px; margin: 3px 0; color: var(--ink); }
        .empty { color: var(--muted); font-size: 13px; text-align: center; padding: 30px 10px; }

        .fw-section { margin-bottom: 20px; }
        .fw-title { font-family: 'Oswald', sans-serif; font-size: 15px; color: var(--amber-bright); text-transform: uppercase; letter-spacing: 0.04em; margin-bottom: 8px; }
        .fw-item { font-size: 13.5px; line-height: 1.5; margin-bottom: 6px; color: var(--ink); }
        .fw-item b { color: var(--cyan); }
      `}</style>

      <div className="header">
        <div className="eyebrow">Intention → Obstacle → Drama</div>
        <div className="h1">The Story Engine</div>
        <div className="sub">Built on Sorkin's drive shaft, Booker's plots, and Polti's 36 situations</div>
      </div>

      <div className="tabs">
        <button className={"tab-btn" + (tab === "generate" ? " active" : "")} onClick={() => setTab("generate")}>Generate</button>
        <button className={"tab-btn" + (tab === "feedback" ? " active" : "")} onClick={() => setTab("feedback")}>Feedback</button>
        <button className={"tab-btn" + (tab === "clash" ? " active" : "")} onClick={() => setTab("clash")}>Clash</button>
        <button className={"tab-btn" + (tab === "frameworks" ? " active" : "")} onClick={() => setTab("frameworks")}>Frameworks</button>
        <button className={"tab-btn" + (tab === "history" ? " active" : "")} onClick={() => setTab("history")}>History</button>
      </div>

      {tab === "generate" && (
        <div className="panel">
          <DriveShaft spinning={loading} />

          <span className="field-label">Framework</span>
          <div className="lens-row">
            {Object.entries(FRAMEWORKS).map(([key, fw]) => (
              <button
                key={key}
                className={"lens-btn" + (framework === key ? " active" : "")}
                onClick={() => { setFramework(key); setLensSeed(""); setResult(null); setError(null); }}
              >
                <span className="lens-btn-label">{fw.label}</span>
                <span className="lens-btn-tagline">{fw.tagline}</span>
              </button>
            ))}
          </div>

          {framework !== "sorkin" && (
            <p className="lens-note">
              {FRAMEWORKS[framework].label} shapes the story built from the Intention/Obstacle below — it doesn't replace them.
            </p>
          )}

          <div className="seed-grid">
            <div>
              <span className="field-label">Intention seed (optional)</span>
              <input type="text" value={seedIntention} onChange={(e) => setSeedIntention(e.target.value)} placeholder="leave blank for random" />
            </div>
            <div>
              <span className="field-label">Obstacle seed (optional)</span>
              <input type="text" value={seedObstacle} onChange={(e) => setSeedObstacle(e.target.value)} placeholder="leave blank for random" />
            </div>
          </div>

          {framework !== "sorkin" && (
            <div style={{ marginBottom: 16 }}>
              <span className="field-label">
                {framework === "booker" ? "Booker plot" : framework === "polti" ? "Polti situation" : "Vonnegut shape"} (optional)
              </span>
              <select value={lensSeed} onChange={(e) => setLensSeed(e.target.value)}>
                <option value="">— leave blank for random —</option>
                {lensList.map((item) => (
                  <option key={item.name} value={item.name}>{item.name}</option>
                ))}
              </select>
            </div>
          )}

          <div className="btn-row">
            <button className="btn primary" disabled={loading} onClick={() => handleGenerate(true)}>
              {loading ? "Generating…" : "Fully Random"}
            </button>
            <button className="btn" disabled={loading} onClick={() => handleGenerate(false)}>
              Generate From Selection Above
            </button>
          </div>

          {error && <div className="error-box">{error}</div>}

          {result && (
            <div className="result">
              <div className="result-title">{result.title}</div>
              <div className="result-tags">
                {result.plotType && <span className="tag">Booker: {result.plotType}</span>}
                {result.polti && <span className="tag">Polti: {result.polti}</span>}
                {result.vonnegutShape && <span className="tag">Vonnegut: {result.vonnegutShape}</span>}
              </div>
              <p className="logline">{result.logline}</p>
              <div className="io-grid">
                <div className="io-card">
                  <span className="field-label">Intention</span>
                  <p>{result.intention}</p>
                </div>
                <div className="io-card">
                  <span className="field-label">Obstacle</span>
                  <p>{result.obstacle}</p>
                </div>
              </div>
              {result.arcNote && (
                <div className="io-card" style={{ marginBottom: 16 }}>
                  <span className="field-label">Arc</span>
                  <p>{result.arcNote}</p>
                </div>
              )}
              <ScoreBand total={scoreTotal(result.scores)} />
              <div className="gauges">
                {RUBRIC.map((r) => (
                  <Gauge key={r.key} label={r.label} value={result.scores && result.scores[r.key]} />
                ))}
              </div>
              {result.pressNotes && <p className="press-notes">{result.pressNotes}</p>}
            </div>
          )}
        </div>
      )}

      {tab === "clash" && (
        <div className="panel">
          <div className="clash-grid">
            <div>
              <span className="field-label">Source A</span>
              <textarea rows={5} value={clashA} onChange={(e) => setClashA(e.target.value)} placeholder="Describe an existing project, series, or idea — visual, written, anything" />
            </div>
            <div>
              <span className="field-label">Source B</span>
              <textarea rows={5} value={clashB} onChange={(e) => setClashB(e.target.value)} placeholder="Describe a second existing project, series, or idea" />
            </div>
          </div>
          <div className="btn-row">
            <button className="btn primary" disabled={loading || !clashA.trim() || !clashB.trim()} onClick={handleClash}>
              {loading ? "Clashing…" : "Clash Them Together"}
            </button>
          </div>

          {error && <div className="error-box">{error}</div>}

          {clashResult && (
            <div className="result">
              <div className="result-title">{clashResult.title}</div>
              <div className="io-grid">
                <div className="io-card">
                  <span className="field-label">Inherited from A</span>
                  <p>{clashResult.fromA}</p>
                </div>
                <div className="io-card">
                  <span className="field-label">Inherited from B</span>
                  <p>{clashResult.fromB}</p>
                </div>
              </div>
              <div className="result-tags">
                {clashResult.plotType && <span className="tag">Booker: {clashResult.plotType}</span>}
                {clashResult.polti && <span className="tag">Polti: {clashResult.polti}</span>}
              </div>
              <p className="logline">{clashResult.logline}</p>
              <div className="io-grid">
                <div className="io-card">
                  <span className="field-label">Hybrid Intention</span>
                  <p>{clashResult.intention}</p>
                </div>
                <div className="io-card">
                  <span className="field-label">Hybrid Obstacle</span>
                  <p>{clashResult.obstacle}</p>
                </div>
              </div>
              <ScoreBand total={scoreTotal(clashResult.scores)} />
              <div className="gauges">
                {RUBRIC.map((r) => (
                  <Gauge key={r.key} label={r.label} value={clashResult.scores && clashResult.scores[r.key]} />
                ))}
              </div>
              {clashResult.pressNotes && <p className="press-notes">{clashResult.pressNotes}</p>}
            </div>
          )}
        </div>
      )}

      {tab === "feedback" && (
        <div className="panel">
          <span className="field-label">Paste a logline, synopsis, or story idea</span>
          <textarea rows={6} value={feedbackInput} onChange={(e) => setFeedbackInput(e.target.value)} placeholder="e.g. A grief counselor discovers her newest client is the man who caused the accident that killed her sister..." />
          <div className="btn-row">
            <button className="btn primary" disabled={loading || !feedbackInput.trim()} onClick={handleFeedback}>
              {loading ? "Analyzing…" : "Run the Pressing Test"}
            </button>
          </div>

          {error && <div className="error-box">{error}</div>}

          {feedbackResult && (
            <div className="result">
              <div className="result-tags">
                {feedbackResult.plotType && <span className="tag">Booker: {feedbackResult.plotType}</span>}
                {feedbackResult.polti && <span className="tag">Polti: {feedbackResult.polti}</span>}
              </div>
              <div className="io-grid">
                <div className="io-card">
                  <span className="field-label">Intention (as read)</span>
                  <p>{feedbackResult.restatedIntention}</p>
                </div>
                <div className="io-card">
                  <span className="field-label">Obstacle (as read)</span>
                  <p>{feedbackResult.restatedObstacle}</p>
                </div>
              </div>
              <ScoreBand total={scoreTotal(feedbackResult.scores)} />
              <div className="gauges">
                {RUBRIC.map((r) => (
                  <Gauge key={r.key} label={r.label} value={feedbackResult.scores && feedbackResult.scores[r.key]} />
                ))}
              </div>
              {feedbackResult.diagnosis && <p className="press-notes" style={{ marginBottom: 14 }}>{feedbackResult.diagnosis}</p>}
              {feedbackResult.strongerObstacle && (
                <div className="io-card">
                  <span className="field-label">Try this obstacle instead</span>
                  <p>{feedbackResult.strongerObstacle}</p>
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {tab === "frameworks" && (
        <div className="panel">
          <div className="fw-section">
            <div className="fw-title">Sorkin's Pressing Test</div>
            {RUBRIC.map((r) => (
              <div className="fw-item" key={r.key}><b>{r.label}:</b> {r.q}</div>
            ))}
          </div>
          <div className="fw-section">
            <div className="fw-title">Booker's 7 Basic Plots</div>
            <div className="fw-item"><b>Overcoming the Monster</b> — protagonist vs. an existential external threat</div>
            <div className="fw-item"><b>Rags to Riches</b> — rise from lack to abundance</div>
            <div className="fw-item"><b>The Quest</b> — journey toward a goal, obstacles escalate</div>
            <div className="fw-item"><b>Voyage and Return</b> — pulled into a strange world, must return changed</div>
            <div className="fw-item"><b>Comedy</b> — confusion obstructs connection, resolved by revelation</div>
            <div className="fw-item"><b>Tragedy</b> — a flaw becomes the true obstacle</div>
            <div className="fw-item"><b>Rebirth</b> — nearly overcome by darkness before a redemptive turn</div>
          </div>
          <div className="fw-section">
            <div className="fw-title">Intention Bank Categories</div>
            <div className="fw-item">{Object.keys(INTENTIONS).join(" · ")}</div>
          </div>
          <div className="fw-section">
            <div className="fw-title">Obstacle Bank Categories</div>
            <div className="fw-item">{Object.keys(OBSTACLES).join(" · ")}</div>
          </div>
          <div className="fw-section">
            <div className="fw-title">Note</div>
            <div className="fw-item" style={{ color: "#7C8DA6" }}>
              Booker, Polti, and Vonnegut are critical taxonomies, not statistically-validated rankings. The full 36 Polti situations and complete Vonnegut/Campbell/Save the Cat tables live in the companion spreadsheet.
            </div>
          </div>
        </div>
      )}

      {tab === "history" && (
        <div className="panel">
          {!historyLoaded ? (
            <div className="empty">Loading…</div>
          ) : history.length === 0 ? (
            <div className="empty">Nothing generated yet — run the engine to build a history here.</div>
          ) : (
            <div className="history-list">
              {history.map((h, i) => (
                <div
                  className="history-item"
                  key={i}
                  onClick={() => {
                    if (h.type === "generate") { setTab("generate"); setResult(h.data); }
                    else if (h.type === "clash") { setTab("clash"); setClashA(h.inputA); setClashB(h.inputB); setClashResult(h.data); }
                    else { setTab("feedback"); setFeedbackInput(h.input); setFeedbackResult(h.data); }
                  }}
                >
                  <div className="h-type">{h.type} · {new Date(h.ts).toLocaleString()}</div>
                  <div className="h-title">{h.type === "feedback" ? (h.data.restatedIntention || "").slice(0, 60) : h.data.title}</div>
                  {h.data.scores && <div style={{ color: "#7C8DA6" }}>{scoreTotal(h.data.scores)}/25 — {bandFor(scoreTotal(h.data.scores)).label}</div>}
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
